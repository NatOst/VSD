package fr.securitasdirect.covea.pfs.dao.pfs;

import fr.securitasdirect.covea.pfs.ProviderCredentials;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsException;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuth;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthLoginException;
import fr.securitasdirect.covea.pfs.dao.pfs.CoveAuthTokenException;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsCartouche;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsContact;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsContactEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withUnauthorizedRequest;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class PfsClientTest {

    @Autowired
    @Value("classpath:/fr/securitasdirect/covea/pfs/dao/pfs/auth/valid_token.json")
    private Resource mockToken;

    @Autowired
    private PfsClient client;

    @Autowired
    @Qualifier("coveAuthTemplate")
    private RestTemplate coveAuthTemplate;

    @Autowired
    @Qualifier("pfsTemplate")
    private RestTemplate pfsTemplate;

    @Autowired
    private ProviderCredentials providerCredentials;

    private MockRestServiceServer coveAuthMockServer;

    private MockRestServiceServer pfsMockServer;

    @Before
    public void setupMockServers() {
        coveAuthMockServer = MockRestServiceServer.bindTo(coveAuthTemplate).build();
        pfsMockServer = MockRestServiceServer.bindTo(pfsTemplate).build();
    }

    @Test
    public void testPublishTwoContactsWithLoginSuccess() throws PfsException {
        coveAuthMockServer
                .expect(requestTo("/coveAuth/authorize"))
                .andRespond(withSuccess(mockToken, MediaType.APPLICATION_JSON));

        pfsMockServer
                .expect(ExpectedCount.times(2), this::matchContactRequest)
                .andRespond(withSuccess());

        client.publishEvent(new PfsContactEvent(new PfsCartouche(), new PfsContact()));
        client.publishEvent(new PfsContactEvent(new PfsCartouche(), new PfsContact()));

        coveAuthMockServer.verify();
        pfsMockServer.verify();
    }

    @Test
    public void testPublishTwoContactsWithLoginSuccessAndTokenRejected() throws PfsException {
        coveAuthMockServer
                .expect(ExpectedCount.times(2), requestTo("/coveAuth/authorize"))
                .andRespond(withSuccess(mockToken, MediaType.APPLICATION_JSON));

        // Pretend token in invalid and reject first request
        pfsMockServer.expect(this::matchContactRequest).andRespond(withUnauthorizedRequest());
        // Accept second request with renewed token
        pfsMockServer.expect(this::matchContactRequest).andRespond(withSuccess());

        try {
            client.publishEvent(new PfsContactEvent(new PfsCartouche(), new PfsContact()));
        } catch (final CoveAuthTokenException e) {
            assertEquals("Exception cause", HttpClientErrorException.class, e.getCause().getClass());
            final HttpClientErrorException cause = (HttpClientErrorException) e.getCause();
            assertEquals("Response status code", HttpStatus.UNAUTHORIZED, cause.getStatusCode());
        }
        client.publishEvent(new PfsContactEvent(new PfsCartouche(), new PfsContact()));

        coveAuthMockServer.verify();
        pfsMockServer.verify();
    }

    @Test(expected = CoveAuthLoginException.class)
    public void testPublishContactWithLoginFailed() throws PfsException {
        coveAuthMockServer
                .expect(requestTo("/coveAuth/authorize"))
                .andRespond(withUnauthorizedRequest());

        client.publishEvent(new PfsContactEvent(new PfsCartouche(), new PfsContact()));

        coveAuthMockServer.verify();
        pfsMockServer.verify();
    }

    private void matchContactRequest(final ClientHttpRequest request) throws IOException, AssertionError {
        assertEquals("Request URI", "/pfs/PUB_SENAT_1", request.getURI().toString());
        assertNotNull("CoveAuth token", request.getHeaders().toSingleValueMap().get(CoveAuth.TOKEN_HEADER));
    }
}
