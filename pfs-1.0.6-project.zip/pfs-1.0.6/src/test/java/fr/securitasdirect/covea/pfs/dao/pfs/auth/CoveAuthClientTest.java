package fr.securitasdirect.covea.pfs.dao.pfs.auth;

import com.auth0.jwt.interfaces.DecodedJWT;
import fr.securitasdirect.covea.pfs.ProviderCredentials;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthClient;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthLoginException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withUnauthorizedRequest;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CoveAuthClientTest {

    @Autowired
    @Value("classpath:/fr/securitasdirect/covea/pfs/dao/pfs/auth/valid_token.json")
    private Resource mockToken;

    @Autowired
    @Value("classpath:/fr/securitasdirect/covea/pfs/dao/pfs/auth/bad_issuer_token.json")
    private Resource badIssuerToken;

    @Autowired
    @Qualifier("coveAuthTemplate")
    private RestTemplate coveAuthTemplate;

    @Autowired
    private CoveAuthClient authClient;

    // TODO Verify credentials are sent
    @Autowired
    private ProviderCredentials providerCredentials;

    private MockRestServiceServer mockServer;

    @Before
    public void setupMockServer() {
        mockServer = MockRestServiceServer.bindTo(coveAuthTemplate).build();
    }

    @Test
    public void testLoginSuccessful() {
        mockServer.expect(requestTo("/coveAuth/authorize")).andRespond(withSuccess(mockToken, MediaType.APPLICATION_JSON));
        final DecodedJWT token = authClient.authenticate();
        assertNotNull(token);
        mockServer.verify();
    }

    @Test(expected = CoveAuthLoginException.class)
    public void testLoginFailed() {
        mockServer.expect(requestTo("/coveAuth/authorize")).andRespond(withUnauthorizedRequest());
        authClient.authenticate();
        mockServer.verify();
    }

    @Test(expected = CoveAuthLoginException.class)
    public void testUnexpectedIssuer() {
        mockServer.expect(requestTo("/coveAuth/authorize")).andRespond(withSuccess(badIssuerToken, MediaType.APPLICATION_JSON));
        authClient.authenticate();
        mockServer.verify();
    }
}
