package fr.securitasdirect.covea.pfs.service;


import fr.securitasdirect.covea.pfs.dao.db.ContactEventDao;
import fr.securitasdirect.covea.pfs.dao.db.CustomerLifeEventDao;
import fr.securitasdirect.covea.pfs.dao.db.DeviceEventDao;
import fr.securitasdirect.covea.pfs.dao.db.model.Event;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;

import static org.junit.Assert.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(locations = "classpath:/integration-sqlserver.properties")
public class OutboundServiceSqlServerIT {

    @Autowired
    @Value("classpath:/fr/securitasdirect/covea/pfs/dao/pfs/auth/valid_token.json")
    private Resource mockToken;

    @Autowired
    @Qualifier("coveAuthTemplate")
    private RestTemplate coveAuthTemplate;

    @Autowired
    @Qualifier("pfsTemplate")
    private RestTemplate pfsTemplate;

    @Autowired
    private ContactEventDao contactEventDao;

    @Autowired
    private CustomerLifeEventDao customerLifeEventDao;

    @Autowired
    private DeviceEventDao deviceEventDao;

    @Autowired
    private OutboundService outboundService;

    private MockRestServiceServer coveAuthMockServer;

    private MockRestServiceServer pfsMockServer;

    @Before
    public void setupMockServers() {
        coveAuthMockServer = MockRestServiceServer.bindTo(coveAuthTemplate).build();
        pfsMockServer = MockRestServiceServer.bindTo(pfsTemplate).build();
    }

    @Test
    @Sql(
            scripts = {"/fr/securitasdirect/covea/pfs/dao/db/sqlserver/contact.sql", "/fr/securitasdirect/covea/pfs/dao/db/sqlserver/customer_life.sql", "/fr/securitasdirect/covea/pfs/dao/db/sqlserver/device.sql"},
            config = @SqlConfig(transactionMode = SqlConfig.TransactionMode.INFERRED)
    )
    @Rollback
    public void publishEvents() {
        coveAuthMockServer
                .expect(requestTo("https://coveauth-vmoa.itmma.fr/coveauth-server/authorize"))
                .andRespond(withSuccess(mockToken, MediaType.APPLICATION_JSON));

        pfsMockServer
                .expect(ExpectedCount.times(22), requestTo("https://api-72-vmoa.itmma.fr/coveo-as/rest/EchangesPartenaires/PUB_SENAT_1"))
                .andRespond(withSuccess());

        outboundService.publishEvents();

        coveAuthMockServer.verify();
        pfsMockServer.verify();

        assertEquals(10, contactEventDao.count());
        contactEventDao.findAll().forEach(this::verifyPublicationTimeIsSet);

        assertEquals(2, customerLifeEventDao.count());
        customerLifeEventDao.findAll().forEach(this::verifyPublicationTimeIsSet);

        assertEquals(10, deviceEventDao.count());
        deviceEventDao.findAll().forEach(this::verifyPublicationTimeIsSet);
    }

    private void verifyPublicationTimeIsSet(final Event event) {
        assertNotNull(event.getPublicationTime());
        assertTrue(event.getPublicationTime().isBefore(Instant.now()));
    }
}
