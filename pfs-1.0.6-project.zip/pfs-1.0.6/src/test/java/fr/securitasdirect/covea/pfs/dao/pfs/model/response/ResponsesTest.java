package fr.securitasdirect.covea.pfs.dao.pfs.model.response;

import fr.securitasdirect.covea.pfs.dao.pfs.model.BaseJsonTest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.json.JsonContent;
import org.springframework.boot.test.json.ObjectContent;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;

@JsonTest
@RunWith(SpringRunner.class)
public class ResponsesTest extends BaseJsonTest {

    private Response r200;

    private Error e403_1, e403_2, e404;

    private JacksonTester<Response> responseTester;

    private JacksonTester<Error> errorTester;

    @Before
    public void buildResponse() {
        r200 = new Response("271d955762054dfabddbb3087266ab3f", "The message has been correctly sent");
    }

    @Before
    public void buildErrors() {
        e403_1 = new Error("e5c84391002545f081de209c73fc4877", "CoveAuth call throws an error(Token cannot be null)");
        e403_2 = new Error("8bf8c5b39ad44a1bb61ddb0ef25369af", "CoveAuth call throws an error(A technical exception has been raised while verifying JWT signature)");
        e404 = new Error("92107814d9c04688ba81129058a4f007", "Problem in the pub code search in cache (There is no publication code PUB_SENAT_1 in the validation line ITTUX03)");
    }

    @Test
    public void testRead200() throws IOException {
        final ObjectContent<Response> json = responseTester.read("200.json");
        assertThat(json).isEqualTo(r200);
    }

    @Test
    public void testWriter200() throws IOException {
        final JsonContent<Response> json = responseTester.write(r200);
        assertThat(json).isEqualToJson("200.json");
    }

    @Test
    public void testRead403_1() throws IOException {
        final ObjectContent<Error> json = errorTester.read("403_1.json");
        assertThat(json).isEqualTo(e403_1);
    }

    @Test
    public void testWriter403_1() throws IOException {
        final JsonContent<Error> json = errorTester.write(e403_1);
        assertThat(json).isEqualToJson("403_1.json");
    }

    @Test
    public void testRead403_2() throws IOException {
        final ObjectContent<Error> json = errorTester.read("403_2.json");
        assertThat(json).isEqualTo(e403_2);
    }

    @Test
    public void testWriter403_2() throws IOException {
        final JsonContent<Error> json = errorTester.write(e403_2);
        assertThat(json).isEqualToJson("403_2.json");
    }

    @Test
    public void testRead404() throws IOException {
        final ObjectContent<Error> json = errorTester.read("404.json");
        assertThat(json).isEqualTo(e404);
    }

    @Test
    public void testWriter404() throws IOException {
        final JsonContent<Error> json = errorTester.write(e404);
        assertThat(json).isEqualToJson("404.json");
    }
}
