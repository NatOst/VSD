package fr.securitasdirect.covea.pfs.dao.db;

import fr.securitasdirect.covea.pfs.dao.db.model.ContactEvent;
import fr.securitasdirect.covea.pfs.dao.db.model.CustomerLifeEvent;
import fr.securitasdirect.covea.pfs.dao.db.model.DeviceEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
public class EventDaoTest {

    @Autowired
    private ContactEventDao contactEventDao;

    @Autowired
    private CustomerLifeEventDao customerLifeEventDao;

    @Autowired
    private DeviceEventDao deviceEventDao;

    @Test
    @Sql(
            scripts = "h2/contact.sql",
            config = @SqlConfig(transactionMode = SqlConfig.TransactionMode.INFERRED)
    )
    @Transactional
    public void testContactEventDao() {
        assertEquals(10, contactEventDao.count());
        contactEventDao.findAll().forEach(ContactEvent::toString);
    }

    @Test
    @Sql(
            scripts = "h2/customer_life.sql",
            config = @SqlConfig(transactionMode = SqlConfig.TransactionMode.INFERRED)
    )
    @Transactional
    public void testCustomerLifeEventDao() {
        assertEquals(2, customerLifeEventDao.count());
        customerLifeEventDao.findAll().forEach(CustomerLifeEvent::toString);
    }

    @Test
    @Sql(
            scripts = "h2/device.sql",
            config = @SqlConfig(transactionMode = SqlConfig.TransactionMode.INFERRED)
    )
    @Transactional
    public void testDeviceEventDao() {
        assertEquals(10, deviceEventDao.count());
        deviceEventDao.findAll().forEach(DeviceEvent::toString);
    }
}
