package fr.securitasdirect.covea.pfs.dao.db.converters;

import fr.securitasdirect.covea.pfs.dao.db.model.ContactChannel;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ContactChannelConverterTest {

    private ContactChannelConverter converter;

    @Before
    public void setup() {
        converter = new ContactChannelConverter();
    }

    @Test
    public void convertsNonNullContactChannel() {
        final String value = converter.convertToDatabaseColumn(ContactChannel.APPEL_ENTRANT);
        Assert.assertEquals("Appel entrant", value);
    }

    @Test
    public void convertsNullContactChannel() {
        final String value = converter.convertToDatabaseColumn(null);
        Assert.assertNull(value);
    }

    @Test
    public void convertsNonNullString() {
        final ContactChannel value = converter.convertToEntityAttribute("Appel entrant");
        Assert.assertEquals(ContactChannel.APPEL_ENTRANT, value);
    }

    @Test
    public void convertsFancyString() {
        final ContactChannel value = converter.convertToEntityAttribute("Non existing");
        Assert.assertNull(value);
    }

    @Test
    public void convertsNullString() {
        final ContactChannel value = converter.convertToEntityAttribute(null);
        Assert.assertNull(value);
    }
}
