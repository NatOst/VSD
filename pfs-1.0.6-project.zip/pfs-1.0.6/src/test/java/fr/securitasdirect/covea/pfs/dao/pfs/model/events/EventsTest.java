package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import fr.securitasdirect.covea.pfs.dao.pfs.model.BaseJsonTest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.json.JsonContent;
import org.springframework.boot.test.json.ObjectContent;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@JsonTest
public class EventsTest extends BaseJsonTest {

    private static final ZonedDateTime EMISSION_TIME = ZonedDateTime.of(2016, 11, 30, 11, 20, 30, 0, ZoneId.of("Z"));

    private PfsContactEvent contactEvent;

    private PfsCustomerLifeEvent customerLifeEvent;

    private PfsDeviceEvent deviceEvent;

    private PfsDeviceEvent deviceEventWithNulls;

    private PfsServiceUsageEvent serviceUsageEvent;

    private JacksonTester<PfsContactEvent> contactEventTester;

    private JacksonTester<PfsCustomerLifeEvent> customerLifeEventTester;

    private JacksonTester<PfsDeviceEvent> deviceEventTester;

    private JacksonTester<PfsServiceUsageEvent> serviceUsageEventTester;

    @Before
    public void buildContactEvent() {
        final PfsCartouche cartouche = new PfsCartouche("YGHTJ432", PfsCustomerBrand.GMF, "Securitas Direct", "Diago",
                EMISSION_TIME, "PFS", "identifiantPersonnePFS", null, "IDCLIENTVERISURE.007");
        final PfsContact contact = new PfsContact();
        contact.setChannel(PfsContactChannel.FACE_A_FACE);
        contact.setDate(ZonedDateTime.of(2016, 11, 29, 11, 20, 30, 0, ZoneId.of("Z")));
        contact.setOutput("Acquisition client");
        contactEvent = new PfsContactEvent(cartouche, contact);
    }

    @Before
    public void buildCustomerLifeEvent() {
        final PfsCartouche cartouche = new PfsCartouche("YGHTJ432", PfsCustomerBrand.GMF, "ARS", "MonQuart",
                EMISSION_TIME, "PFS", "identifiantPersonnePFS", null, null);
        final PfsCustomerLife customerLife = new PfsCustomerLife();
        customerLife.setPrefixChanged(Boolean.TRUE);
        customerLife.setLastNameChanged(Boolean.FALSE);
        customerLife.setFirstNameChanged(Boolean.TRUE);
        customerLife.setStreetChanged(Boolean.FALSE);
        customerLife.setPostcodeChanged(Boolean.TRUE);
        customerLife.setCityChanged(Boolean.FALSE);
        customerLife.setCountryChanged(Boolean.TRUE);
        customerLife.setHomePhoneNumberChanged(Boolean.FALSE);
        customerLife.setMobilePhoneNumberChanged(Boolean.TRUE);
        customerLife.setEmailChanged(Boolean.FALSE);

        customerLifeEvent = new PfsCustomerLifeEvent(cartouche, customerLife);
    }

    @Before
    public void buildDeviceEvent() {
        final PfsCartouche cartouche = new PfsCartouche("YGHTJ432", PfsCustomerBrand.GMF, "ARS", "MonQuart",
                EMISSION_TIME, "PFS", "identifiantPersonnePFS", "123456", null);
        cartouche.setProviderDeviceId("123456");
        final PfsDevice device = new PfsDevice();
        device.setUsage(ZonedDateTime.of(2016, 11, 29, 11, 20, 30, 0, ZoneId.of("Z")));
        device.setStart(ZonedDateTime.of(2016, 10, 01, 0, 0, 0, 0, ZoneId.of("Z")));
        device.setEnd(ZonedDateTime.of(2017, 01, 01, 0, 0, 0, 0, ZoneId.of("Z")));
        device.setServiceName("Mon Quartier - 25 rue du Labrador");
        device.setStatus("CONSOMME");
        device.setServiceURL("https://mon-quartier?m=gmf&@47.9774909,0.2877582,17z/data=!4m2!10m1!1e2");
        device.setPrice(BigDecimal.valueOf(120, 1));
        device.setPriceSplitting(PfsPriceSplitting.MENSUEL);
        deviceEvent = new PfsDeviceEvent(cartouche, device);
    }

    @Before
    public void buildDeviceEventWithNulls() {
        final PfsCartouche cartouche = new PfsCartouche("YGHTJ432", PfsCustomerBrand.GMF, "ARS", "MonQuart",
                EMISSION_TIME, "PFS", "identifiantPersonnePFS", "123456", null);
        cartouche.setProviderDeviceId("123456");
        final PfsDevice device = new PfsDevice();
        device.setUsage(ZonedDateTime.of(2016, 11, 29, 11, 20, 30, 0, ZoneId.of("Z")));
        device.setStart(null);
        device.setEnd(null);
        device.setServiceName("Mon Quartier - 25 rue du Labrador");
        device.setStatus("CONSOMME");
        device.setServiceURL("https://mon-quartier?m=gmf&@47.9774909,0.2877582,17z/data=!4m2!10m1!1e2");
        device.setPrice(BigDecimal.valueOf(120, 1));
        device.setPriceSplitting(PfsPriceSplitting.MENSUEL);
        deviceEventWithNulls = new PfsDeviceEvent(cartouche, device);
    }

//    @Before
    public void buildServiceUsageEvent() {
        final PfsCartouche cartouche = new PfsCartouche("YGHTJ432", PfsCustomerBrand.GMF, "ARS", "ARS-MonQuartier",
                EMISSION_TIME, "PFS", "identifiantPersonnePFS", null, null);
        cartouche.setProviderDeviceId("123456");
        final PfsServiceUsage serviceUsage = new PfsServiceUsage();
        serviceUsageEvent = new PfsServiceUsageEvent(cartouche, serviceUsage);
    }

    @Test
    public void testWriteContactEvent() throws IOException {
        final JsonContent<PfsContactEvent> json = this.contactEventTester.write(contactEvent);
        assertThat(json).isEqualToJson("contactEvent.json");
    }

    @Test
    public void testReadContactEvent() throws IOException {
        final ObjectContent<PfsContactEvent> json = this.contactEventTester.read("contactEvent.json");
        assertThat(json).isEqualTo(contactEvent);
    }

    @Test
    public void testWriteCustomerLifeEvent() throws IOException {
        final JsonContent<PfsCustomerLifeEvent> json = this.customerLifeEventTester.write(customerLifeEvent);
        assertThat(json).isEqualToJson("customerLifeEvent.json");
    }

    @Test
    public void testReadCustomerLifeEvent() throws IOException {
        final ObjectContent<PfsCustomerLifeEvent> json = this.customerLifeEventTester.read("customerLifeEvent.json");
        assertThat(json).isEqualTo(customerLifeEvent);
    }

    @Test
    public void testWriteDeviceEvent() throws IOException {
        final JsonContent<PfsDeviceEvent> json = this.deviceEventTester.write(deviceEvent);
        assertThat(json).isEqualToJson("deviceEvent.json");
    }

    @Test
    public void testReadDeviceEvent() throws IOException {
        final ObjectContent<PfsDeviceEvent> json = this.deviceEventTester.read("deviceEvent.json");
        assertThat(json).isEqualTo(deviceEvent);
    }

    @Test
    public void testWriteDeviceEventWithNulls() throws IOException {
        final JsonContent<PfsDeviceEvent> json = this.deviceEventTester.write(deviceEventWithNulls);
        assertThat(json).isEqualToJson("deviceEvent_nulls.json");
    }

    @Test
    public void testReadDeviceEventWithNulls() throws IOException {
        final ObjectContent<PfsDeviceEvent> json = this.deviceEventTester.read("deviceEvent_nulls.json");
        assertThat(json).isEqualTo(deviceEventWithNulls);
    }

//    @Test
    public void testWriteServiceUsageEvent() throws IOException {
        final JsonContent<PfsServiceUsageEvent> json = this.serviceUsageEventTester.write(serviceUsageEvent);
        assertThat(json).isEqualToJson("serviceUsageEvent.json");
    }

//    @Test
    public void testReadServiceUsageEvent() throws IOException {
        final ObjectContent<PfsServiceUsageEvent> json = this.serviceUsageEventTester.read("serviceUsageEvent.json");
        assertThat(json).isEqualTo(serviceUsageEvent);
    }
}
