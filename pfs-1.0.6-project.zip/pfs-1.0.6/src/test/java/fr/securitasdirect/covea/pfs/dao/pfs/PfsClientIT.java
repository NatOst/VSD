package fr.securitasdirect.covea.pfs.dao.pfs;

import fr.securitasdirect.covea.pfs.dao.pfs.model.BaseJsonTest;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsClient;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsException;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsContactEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsCustomerLifeEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsDeviceEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsServiceUsageEvent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(locations = "classpath:/integration.properties")
public class PfsClientIT extends BaseJsonTest {

    private JacksonTester<PfsContactEvent> contactEventTester;

    private JacksonTester<PfsCustomerLifeEvent> customerLifeEventTester;

    private JacksonTester<PfsDeviceEvent> deviceEventTester;

    private JacksonTester<PfsServiceUsageEvent> serviceUsageEventTester;

    private PfsContactEvent contactEvent;

    private PfsCustomerLifeEvent customerLifeEvent;

    private PfsDeviceEvent deviceEvent;

    private PfsServiceUsageEvent serviceUsageEvent;

    @Autowired
    private PfsClient pfsClient;

    @Before
    public void loadEvents() throws IOException {
        contactEvent = this.contactEventTester.read("/fr/securitasdirect/covea/pfs/dao/pfs/model/events/contactEvent.json").getObject();
        customerLifeEvent = this.customerLifeEventTester.read("/fr/securitasdirect/covea/pfs/dao/pfs/model/events/customerLifeEvent.json").getObject();
        deviceEvent = this.deviceEventTester.read("/fr/securitasdirect/covea/pfs/dao/pfs/model/events/deviceEvent.json").getObject();
        serviceUsageEvent = this.serviceUsageEventTester.read("/fr/securitasdirect/covea/pfs/dao/pfs/model/events/serviceUsageEvent.json").getObject();
    }

    @Test
    public void testPublishContactEvent() throws PfsException {
        pfsClient.publishEvent(contactEvent);
    }

    @Test
    public void testPublishCustomerLifeEvent() throws PfsException {
        pfsClient.publishEvent(customerLifeEvent);
    }

    @Test
    public void testPublishDeviceEvent() throws PfsException {
        pfsClient.publishEvent(deviceEvent);
    }

    @Test
    public void testPublishServiceUsageEvent() throws PfsException {
        pfsClient.publishEvent(serviceUsageEvent);
    }
}
