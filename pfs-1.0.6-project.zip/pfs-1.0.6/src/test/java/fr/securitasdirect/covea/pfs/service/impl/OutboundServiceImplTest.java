package fr.securitasdirect.covea.pfs.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

@RunWith(MockitoJUnitRunner.class)
public class OutboundServiceImplTest {

    @Mock
    private EventPublisher eventPublisher1, eventPublisher2;

    private OutboundServiceImpl service;

    @Before
    public void setupService() {
        service = new OutboundServiceImpl(Arrays.asList(eventPublisher1, eventPublisher2));
    }

    @Test
    public void testPublication() {
        service.publishEvents();
        Mockito.verify(eventPublisher1, Mockito.times(1)).publishEvents();
        Mockito.verify(eventPublisher2, Mockito.times(1)).publishEvents();
    }
}
