package fr.securitasdirect.covea.pfs.service.impl;

import fr.securitasdirect.covea.pfs.Application;
import fr.securitasdirect.covea.pfs.dao.db.ContactEventDao;
import fr.securitasdirect.covea.pfs.dao.db.model.ContactEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsClient;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsException;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsContactEvent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EventPublisherImplTest {

    private final EventMapper eventMapper = new EventMapperImpl();

    private static final String SAVEPOINT = "savepoint";

    @Mock
    private ContactEventDao eventDao;

    @Mock
    private PfsClient pfsClient;

    @Mock
    private PlatformTransactionManager txManager;

    @Mock
    private TransactionStatus txStatus;

    @Mock
    private CounterService counterService;

    private EventPublisherImpl<ContactEvent, PfsContactEvent> eventPublisher;

    @Before
    public void setupEventPublisher() {
        eventPublisher = new EventPublisherImpl<>(ContactEvent.class, eventDao, eventMapper::contactEventToPfs, pfsClient, txManager, counterService);
        when(txManager.getTransaction(any())).thenReturn(txStatus);
    }

    /**
     * Cas nominal :
     * * Un savepoint doit être créé et validé pour chaque événement.
     * * Aucun rollback ne doit avoir lieu.
     * * La transaction doit être validée.
     * * Les dates d'émission doivent être renseignées.
     */
    @Test
    public void testPublishEvents() throws PfsException {
        final ContactEvent event1 = new ContactEvent();
        final ContactEvent event2 = new ContactEvent();
        assertNull(event1.getPublicationTime());
        assertNull(event2.getPublicationTime());
        when(eventDao.findAllByPublicationTimeNullOrderByInsertionTimeAsc()).thenReturn(Arrays.asList(event1, event2));
        when(eventDao.countAllByPublicationTimeNull()).thenReturn(2L);

        eventPublisher.publishEvents();

        verify(pfsClient, times(2)).publishEvent(any());
        verify(txManager, times(2)).commit(txStatus);
        verify(counterService, times(2)).increment(Application.COUNTER_EVENTS_PUBLISHED + ContactEvent.class.getSimpleName());

        assertNotNull(event1.getPublicationTime());
        assertNotNull(event2.getPublicationTime());
    }

    /**
     * Absence d'événements :
     * * Aucune transaction ne doit être validée.
     * * Aucun élément ne doit être publié.
     */
    @Test
    public void testPublishNoEvent() throws PfsException {
        when(eventDao.countAllByPublicationTimeNull()).thenReturn(0L);
        when(eventDao.findAllByPublicationTimeNullOrderByInsertionTimeAsc()).thenReturn(Collections.emptyList());

        eventPublisher.publishEvents();

        verify(txManager, never()).commit(txStatus);
        verify(pfsClient, never()).publishEvent(any());
        verify(counterService, never()).increment(anyString());
    }

    /**
     * Exception du client à l'envoi d'un événement.
     * * Il doit y avoir un rollback au savepoint.
     * * La transaction doit être commitée.
     * * La date d'émission ne doit pas être renseignée.
     */
    @Test
    public void testPublishEventFail() throws PfsException {
        final ContactEvent event1 = new ContactEvent();
        assertNull(event1.getCartouche().getEmissionTime());
        when(eventDao.findAllByPublicationTimeNullOrderByInsertionTimeAsc()).thenReturn(Collections.singletonList(event1));
        doThrow(PfsException.class).when(pfsClient).publishEvent(any());

        eventPublisher.publishEvents();

        verify(txManager, never()).commit(txStatus);
        verify(txManager, times(1)).rollback(txStatus);
        verify(counterService, times(1)).increment(Application.COUNTER_EVENTS_FAILED + ContactEvent.class.getSimpleName());

        assertNull(event1.getCartouche().getEmissionTime());
    }

}
