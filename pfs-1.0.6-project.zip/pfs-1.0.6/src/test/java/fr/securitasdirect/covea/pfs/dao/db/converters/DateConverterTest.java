package fr.securitasdirect.covea.pfs.dao.db.converters;

import org.junit.Test;

import java.time.LocalDate;

import static org.junit.Assert.*;

public class DateConverterTest {

    private final DateConverter converter = new DateConverter();

    @Test
    public void testConvertsAttribute() {
        final LocalDate date = LocalDate.parse("2016-02-01");
        final String value = converter.convertToDatabaseColumn(date);
        assertEquals("01/02/2016", value);
    }

    @Test
    public void testConvertsValue() {
        final String value = "01/02/2016";
        final LocalDate expected = LocalDate.parse("2016-02-01");
        final LocalDate parsed = converter.convertToEntityAttribute(value);
        assertTrue(expected.isEqual(parsed));
    }

    @Test
    public void testConvertsNullAttribute() {
        assertNull(converter.convertToDatabaseColumn(null));
    }

    @Test
    public void testConvertsNullValue() {
        assertNull(converter.convertToEntityAttribute(null));
    }
}
