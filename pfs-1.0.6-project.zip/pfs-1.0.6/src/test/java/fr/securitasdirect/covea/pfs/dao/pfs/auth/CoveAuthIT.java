package fr.securitasdirect.covea.pfs.dao.pfs.auth;

import com.auth0.jwt.interfaces.DecodedJWT;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(locations = "classpath:/integration.properties")
public class CoveAuthIT {

    @Autowired
    private CoveAuthClient authClient;

    @Test
    public void testAuthentication() {
        final DecodedJWT token = authClient.authenticate();
        Assert.assertNotNull(token);
    }
}
