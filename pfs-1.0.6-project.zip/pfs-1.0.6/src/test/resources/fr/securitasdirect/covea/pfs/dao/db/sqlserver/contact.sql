DELETE FROM [uid329_Contact];
INSERT INTO [uid329_Contact] (
  [cdTypeEvt], [date_insert_SD], [ID_Client], [Marque], [IDfournisseur], [IDclientfournisseur], [Date_Emission], [cdLeadCovea], [IdLeadCovea], [IdOffre], [IdEquipementfournisseur], [Date_contact], [canal_contact], [Issue_contact]
) VALUES
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), NULL, 'GMF', 'Verisure', NULL, NULL, 'PFS', '12345', NULL, NULL, NULL, 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), '999999', 'GMF', 'Verisure', NULL, '07/11/2016', 'PFS', '999999', NULL, NULL, '07/11/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000056165', 'GMF', 'Verisure', NULL, '24/01/2017', 'PFS', '001910400Y', NULL, NULL, '24/01/2017', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000350910', 'GMF', 'Verisure', NULL, '26/12/2016', 'PFS', '001842438B', NULL, NULL, '26/12/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000405811', 'GMF', 'Verisure', NULL, '30/12/2016', 'PFS', '001853165L', NULL, NULL, '30/12/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000421405', 'GMF', 'Verisure', NULL, '25/10/2016', 'PFS', '001702612S', NULL, NULL, '25/10/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000439207', 'GMF', 'Verisure', NULL, '09/08/2016', 'PFS', '001521375V', NULL, NULL, '09/08/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000444267', 'GMF', 'Verisure', NULL, '12/05/2016', 'PFS', '001282986B', NULL, NULL, '12/05/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000501031', 'GMF', 'Verisure', NULL, '09/08/2016', 'PFS', '001521751D', NULL, NULL, '09/08/2016', 'Demande de rappel', NULL),
  ('Contact', CONVERT(datetime, '2017-03-31 14:17:53.740', 121), 'A0000600138', 'GMF', 'Verisure', NULL, '09/12/2016', 'PFS', '001809297D', NULL, NULL, '09/12/2016', 'Demande de rappel', NULL)
;
