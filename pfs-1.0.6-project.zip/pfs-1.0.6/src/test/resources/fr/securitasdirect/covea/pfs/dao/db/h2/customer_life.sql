DELETE FROM "uid329_Client";

INSERT INTO "uid329_Client" (
  "date_insert_SD", "ID_Client", "Marque", "IDfournisseur", "IDclientfournisseur", "Date_Emission", "cdLeadCovea", "IdLeadCovea", "IdOffre", "IdEquipementfournisseur", "civilité", "nom", "prenom", "rue", "codePostal", "commune", "pays", "tel_dom", "tel_GSM", "email"
) VALUES
  (PARSEDATETIME('2017-04-03 11:47:02.680', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'),'E0001640156','GMF','Verisure','E415008','29/03/2017','AIS','002031923N',NULL,NULL,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,TRUE,FALSE),
  (PARSEDATETIME('2017-04-03 11:47:02.680', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'),'V000C864776','GMF','Verisure','E415176','27/03/2017','AIS','002036767D',NULL,NULL,FALSE,FALSE,FALSE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE)
;