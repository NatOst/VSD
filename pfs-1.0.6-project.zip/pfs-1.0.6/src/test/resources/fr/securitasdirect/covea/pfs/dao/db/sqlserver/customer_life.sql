DELETE FROM [uid329_Client];
INSERT INTO [uid329_Client] (
  [cdTypeEvt], [date_insert_SD], [ID_Client], [Marque], [IDfournisseur], [IDclientfournisseur], [Date_Emission], [cdLeadCovea], [IdLeadCovea], [IdOffre], [IdEquipementfournisseur], [civilité], [nom], [prenom], [rue], [codePostal], [commune], [pays], [tel_dom], [tel_GSM], [email]
) VALUES
  ('Client', CONVERT(datetime, '2017-04-03 11:47:02.680', 121),'E0001640156','GMF','Verisure','E415008','29/03/2017','AIS','002031923N',NULL,NULL,0,0,0,0,0,0,0,0,1,0),
  ('Client', CONVERT(datetime, '2017-04-03 11:47:02.680', 121),'V000C864776','GMF','Verisure','E415176','27/03/2017','AIS','002036767D',NULL,NULL,0,0,0,1,0,0,0,0,0,0)
;