DELETE FROM "uid329_Equipement";

INSERT INTO "uid329_Equipement" (
  "date_insert_SD", "ID_Client", "Marque", "IDfournisseur", "IDclientfournisseur", "Date_Emission", "cdLeadCovea", "IdLeadCovea", "IdOffre", "IdEquipementfournisseur", "Id_Offre", "Libellé", "Date_Souscription", "Cotisation", "EtatEquipement"
) VALUES
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'A12737', '24/02/2010', NULL, NULL, 'Solo', 118720, 118720, 'Solo 16 Bis Route De La Levee Verte 17880 LES PORTES EN RE', '02/01/2009', 18.59, 'Actif'),
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'A17958', '24/02/2010', NULL, NULL, 'Solo', 110867, 110867, 'Solo 40 Rue De La Tour Malborough 28700 DENONVILLE', '04/08/2008', 38.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E009525', '24/02/2010', NULL, NULL, 'Duo', 113671, 113671, NULL, '04/08/2008', 44.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E018191', '24/02/2010', NULL, NULL, 'Duo', 110876, 110876, 'Duo 230 Chemin De La Barrière 83440 MONTAUROUX', '12/06/2008', 41.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E018883', '24/02/2010', NULL, NULL, 'Solo', 111026, 111026, 'Solo 5 Rue Des Vallees 91800 BRUNOY', '10/06/2008', 42.40, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E019582', '06/04/2016', NULL, NULL, 'Solo', 111236, 111236, 'Solo 29 Hameau Du Prieure Chemin De Lorette 69230 ST GENIS LAVAL', '18/06/2008', 39.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E019695', '24/02/2010', NULL, NULL, 'Duo', 111442, 111442, 'Duo 1 Place Ellie De Beaumont 66000 PERPIGNAN', '24/11/2009', 43.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E020327', '24/02/2010', NULL, NULL, 'Solo', 111429, 111429, 'Solo 7 Rue Du Roty 77148 SALINS', '19/06/2008', 38.90, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E020344', '24/02/2010', NULL, NULL, 'Solo', 111942, 111942, 'Solo 248 Chemin De La Carreirade 13119 ST SAVOURNIN', '08/07/2008', 35.10, 'Actif'), 
  (PARSEDATETIME('2017-04-03 10:52:13.430', $$yyyy-MM-dd' 'HH:mm:ss.SSS$$, 'fr', 'Z'), NULL, NULL, 'Verisure', 'E020409', '24/02/2010', NULL, NULL, 'Solo', 111498, 111498, NULL, '27/06/2008', 34.27, 'Actif')
;