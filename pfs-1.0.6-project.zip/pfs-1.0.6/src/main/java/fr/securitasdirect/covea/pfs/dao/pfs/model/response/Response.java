package fr.securitasdirect.covea.pfs.dao.pfs.model.response;

import com.fasterxml.jackson.annotation.JsonRootName;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Objects;

@JsonRootName("response")
public class Response extends BaseResponse {
    private String description;

    public Response() {
    }

    public Response(final String instanceId, final String description) {
        super(instanceId);
        this.description = description;
    }

    public final String getDescription() {
        return description;
    }

    public final void setDescription(final String description) {
        this.description = description;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        final Response response = (Response) o;
        return Objects.equals(description, response.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), description);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("description", description)
                .toString();
    }
}
