package fr.securitasdirect.covea.pfs.service;

public interface OutboundService {
    void publishEvents();
}
