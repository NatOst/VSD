package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("VIE_DU_CLIENT")
public class PfsCustomerLifeEvent extends BasePfsEvent<PfsCustomerLife> {
    public PfsCustomerLifeEvent() {
    }

    public PfsCustomerLifeEvent(final PfsCartouche cartouche, final PfsCustomerLife payload) {
        super(cartouche, payload);
    }

    @Override
    @JsonProperty("donneesFonctionnelles")
    public PfsCustomerLife getPayload() {
        return super.payload;
    }
}
