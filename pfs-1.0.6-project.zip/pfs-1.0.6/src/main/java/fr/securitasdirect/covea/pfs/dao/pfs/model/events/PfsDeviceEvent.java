package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("EQUIPEMENT")
public class PfsDeviceEvent extends BasePfsEvent<PfsDevice> {

    public PfsDeviceEvent() {
    }

    public PfsDeviceEvent(final PfsCartouche cartouche, final PfsDevice payload) {
        super(cartouche, payload);
    }

    @Override
    @JsonProperty("detailEquipement")
    public PfsDevice getPayload() {
        return super.payload;
    }
}
