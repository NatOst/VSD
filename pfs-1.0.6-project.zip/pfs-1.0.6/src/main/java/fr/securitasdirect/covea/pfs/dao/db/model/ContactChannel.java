package fr.securitasdirect.covea.pfs.dao.db.model;

public enum ContactChannel {
    FACE_A_FACE,
    MAIL,
    APPEL_ENTRANT,
    APPEL_SORTANT,
    CALLBACK
}
