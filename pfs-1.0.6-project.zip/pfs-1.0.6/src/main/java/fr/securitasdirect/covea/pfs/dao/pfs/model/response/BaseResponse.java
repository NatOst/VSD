package fr.securitasdirect.covea.pfs.dao.pfs.model.response;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Objects;

public abstract class BaseResponse {
    private String instanceId;

    BaseResponse() {
    }

    BaseResponse(final String instanceId) {
        this.instanceId = instanceId;
    }

    public final String getInstanceId() {
        return instanceId;
    }

    public final void setInstanceId(final String instanceId) {
        this.instanceId = instanceId;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final BaseResponse that = (BaseResponse) o;
        return Objects.equals(instanceId, that.instanceId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(instanceId);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("instanceId", instanceId)
                .toString();
    }
}
