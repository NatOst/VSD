package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "\"uid329_Client\"")
public class CustomerLifeEvent extends BaseEvent<CustomerLife> {
    public CustomerLifeEvent() {
    }

    public CustomerLifeEvent(final Cartouche cartouche, final CustomerLife payload) {
        super(cartouche, payload);
    }
}
