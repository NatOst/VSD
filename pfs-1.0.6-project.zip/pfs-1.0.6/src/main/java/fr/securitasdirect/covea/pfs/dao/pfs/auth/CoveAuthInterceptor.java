package fr.securitasdirect.covea.pfs.dao.pfs.auth;

import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.time.Instant;
import java.util.Date;

public class CoveAuthInterceptor implements ClientHttpRequestInterceptor {

    private final ThreadLocal<DecodedJWT> tokenHolder;

    @Autowired
    public CoveAuthInterceptor(final CoveAuthClient authClient) {
        tokenHolder = ThreadLocal.withInitial(authClient::authenticate);
    }

    @Override
    public ClientHttpResponse intercept(final HttpRequest request, final byte[] body, final ClientHttpRequestExecution execution) throws IOException {
        final DecodedJWT decodedJWT = fetchToken();
        request.getHeaders().set(CoveAuth.TOKEN_HEADER, decodedJWT.getToken());
        final ClientHttpResponse response = execution.execute(request, body);
        if (HttpStatus.UNAUTHORIZED.equals(response.getStatusCode())) {
            tokenHolder.remove();
        }
        return response;
    }

    private DecodedJWT fetchToken() {
        final DecodedJWT currentToken = tokenHolder.get();
        final Date expires = currentToken.getExpiresAt();
        if (expires != null && Instant.now().isAfter(expires.toInstant())) {
            tokenHolder.remove();
            return tokenHolder.get();
        } else {
            return currentToken;
        }
    }
}
