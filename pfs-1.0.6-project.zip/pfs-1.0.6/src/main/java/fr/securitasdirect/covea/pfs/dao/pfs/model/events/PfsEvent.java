package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

public interface PfsEvent<T extends PfsPayload> {
    PfsCartouche getCartouche();

    T getPayload();
}
