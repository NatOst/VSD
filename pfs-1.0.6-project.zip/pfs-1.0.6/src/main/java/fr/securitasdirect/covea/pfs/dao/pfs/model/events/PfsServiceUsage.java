package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class PfsServiceUsage implements PfsPayload {
    @Override
    public boolean equals(final Object obj) {
        return obj instanceof PfsServiceUsage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .toString();
    }
}
