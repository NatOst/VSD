package fr.securitasdirect.covea.pfs.dao.db.model;

@Deprecated
public enum CoveaLead {
    PFS,
    AIS
}
