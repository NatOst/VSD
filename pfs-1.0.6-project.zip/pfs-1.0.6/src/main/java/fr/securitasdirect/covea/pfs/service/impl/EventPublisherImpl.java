package fr.securitasdirect.covea.pfs.service.impl;

import fr.securitasdirect.covea.pfs.Application;
import fr.securitasdirect.covea.pfs.dao.db.EventDao;
import fr.securitasdirect.covea.pfs.dao.db.model.Event;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsClient;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsException;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsEvent;
import org.jboss.logging.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicLong;

class EventPublisherImpl<E extends Event, P extends PfsEvent> implements EventPublisher {

    private static final Logger LOGGER = LoggerFactory.getLogger(EventPublisher.class);

    private final EventDao<E> eventDao;

    private final EventMappingOperator<E, P> mappingOperator;

    private final PfsClient pfsClient;

    private final PlatformTransactionManager txManager;

    private final Class<E> eventKind;

    private final DefaultTransactionDefinition nestedTxDefinition;

    private final CounterService counterService;

    private final String publishedCounterName;

    private final String failedCounterName;

    EventPublisherImpl(final Class<E> eventKind, final EventDao<E> eventDao, final EventMappingOperator<E, P> mappingOperator, final PfsClient pfsClient, final PlatformTransactionManager txManager, final CounterService counterService) {
        this.eventKind = eventKind;
        this.eventDao = eventDao;
        this.mappingOperator = mappingOperator;
        this.pfsClient = pfsClient;
        this.txManager = txManager;
        this.counterService = counterService;
        this.nestedTxDefinition = new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_NESTED);
        this.publishedCounterName = Application.COUNTER_EVENTS_PUBLISHED + eventKind.getSimpleName();
        this.failedCounterName = Application.COUNTER_EVENTS_FAILED + eventKind.getSimpleName();
    }

    @Override
    public final void publishEvents() {
        MDC.put(Application.MDC_EVENT_KIND, this.eventKind.getSimpleName());
        final long count = eventDao.countAllByPublicationTimeNull();
        final AtomicLong counter = new AtomicLong();
        LOGGER.info("Starting publishing {} events", count);
        try {
            eventDao.findAllByPublicationTimeNullOrderByInsertionTimeAsc().forEach(e -> publishEvent(e, counter));
            LOGGER.info("Published {} events of {}", counter.get(), count);
        } finally {
            MDC.remove(Application.MDC_EVENT_KIND);
        }
    }

    private void publishEvent(final E event, final AtomicLong counter) {
        final TransactionStatus subTx = txManager.getTransaction(nestedTxDefinition);
        final P pfsEvent = mappingOperator.apply(event);
        try {
            pfsClient.publishEvent(pfsEvent);
            event.setPublicationTime(Instant.now());
            eventDao.save(event);
            txManager.commit(subTx);
            counter.incrementAndGet();
            counterService.increment(publishedCounterName);
            LOGGER.debug("Published event: {}", event);
        } catch (final PfsException e) {
            counterService.increment(failedCounterName);
            LOGGER.warn("Could not publish event: {}", event, e);
            txManager.rollback(subTx);
        }
    }
}
