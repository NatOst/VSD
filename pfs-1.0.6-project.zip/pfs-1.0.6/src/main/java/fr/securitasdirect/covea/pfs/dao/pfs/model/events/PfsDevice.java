package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.Optional;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

public class PfsDevice implements PfsPayload {

    @JsonProperty("idEquipement")
    private String deviceId;

    @JsonProperty("dateConsommationService")
    private ZonedDateTime usage;

    @JsonProperty("dateDebutEffet")
    @JsonInclude(NON_NULL)
    private ZonedDateTime start;

    @JsonProperty("dateFinEffet")
    @JsonInclude(NON_NULL)
    private ZonedDateTime end;

    @JsonProperty("libelleService")
    private String serviceName;

    @JsonProperty("urlService")
    @JsonInclude(NON_NULL)
    private String serviceURL;

    @JsonProperty("etatEquipement")
    private String status;

    @JsonProperty("prix")
    @JsonInclude(NON_NULL)
    private BigDecimal price;

    @JsonProperty("cdFractionnementPaiement")
    @JsonInclude(NON_NULL)
    private PfsPriceSplitting priceSplitting;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    public ZonedDateTime getUsage() {
        return usage;
    }

    public void setUsage(final ZonedDateTime usage) {
        this.usage = usage;
    }

    public ZonedDateTime getStart() {
        return start;
    }

    public void setStart(final ZonedDateTime start) {
        this.start = start;
    }

    public ZonedDateTime getEnd() {
        return end;
    }

    public void setEnd(final ZonedDateTime end) {
        this.end = end;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(final String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceURL() {
        return serviceURL;
    }

    public void setServiceURL(final String serviceURL) {
        this.serviceURL = serviceURL;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(final BigDecimal price) {
        this.price = price;
    }

    public PfsPriceSplitting getPriceSplitting() {
        return priceSplitting;
    }

    public void setPriceSplitting(final PfsPriceSplitting priceSplitting) {
        this.priceSplitting = priceSplitting;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final PfsDevice device = (PfsDevice) o;
        return Objects.equals(deviceId, device.deviceId) &&
                Optional.ofNullable(usage).map(u -> u.isEqual(device.usage)).orElse(device.usage == null) &&
                Optional.ofNullable(start).map(s -> s.isEqual(device.start)).orElse(device.start == null) &&
                Optional.ofNullable(end).map(e -> e.isEqual(device.end)).orElse(device.end == null) &&
                Objects.equals(serviceName, device.serviceName) &&
                Objects.equals(serviceURL, device.serviceURL) &&
                Objects.equals(status, device.status) &&
                Objects.equals(price, device.price) &&
                Objects.equals(priceSplitting, device.priceSplitting);
    }

    @Override
    public int hashCode() {
        return Objects.hash(deviceId, usage, start, end, serviceName, serviceURL, status, price, priceSplitting);
    }
}
