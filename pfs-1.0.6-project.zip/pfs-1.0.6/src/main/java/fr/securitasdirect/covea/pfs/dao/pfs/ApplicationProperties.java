package fr.securitasdirect.covea.pfs.dao.pfs;

import fr.securitasdirect.covea.pfs.CoveAuthProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.support.CronTrigger;

@ConfigurationProperties("application")
public final class ApplicationProperties {
    private final ConnectionProperties pfs;

    private final CoveAuthProperties coveAuth;

    private CronTrigger schedule;

    private String proxyHost;

    private int proxyPort;

    public ApplicationProperties() {
        this.pfs = new ConnectionProperties();
        this.coveAuth = new CoveAuthProperties();
    }

    public ConnectionProperties getPfs() {
        return pfs;
    }

    public CoveAuthProperties getCoveAuth() {
        return coveAuth;
    }

    public CronTrigger getSchedule() {
        return schedule;
    }

    public void setSchedule(final CronTrigger schedule) {
        this.schedule = schedule;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public void setProxyHost(final String proxyHost) {
        this.proxyHost = proxyHost;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    public void setProxyPort(final int proxyPort) {
        this.proxyPort = proxyPort;
    }
}
