package fr.securitasdirect.covea.pfs.dao.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class ServiceUsage implements Payload {
    @Override
    public boolean equals(final Object obj) {
        return obj instanceof ServiceUsage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .toString();
    }
}
