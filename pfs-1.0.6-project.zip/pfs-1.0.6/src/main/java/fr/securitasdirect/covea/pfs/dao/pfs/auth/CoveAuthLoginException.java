package fr.securitasdirect.covea.pfs.dao.pfs.auth;

public class CoveAuthLoginException extends RuntimeException {
    public CoveAuthLoginException() {
    }

    public CoveAuthLoginException(final String message) {
        super(message);
    }

    public CoveAuthLoginException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public CoveAuthLoginException(final Throwable cause) {
        super(cause);
    }

    public CoveAuthLoginException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
