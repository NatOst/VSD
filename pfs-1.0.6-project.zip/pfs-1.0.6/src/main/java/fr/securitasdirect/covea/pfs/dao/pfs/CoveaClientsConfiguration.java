package fr.securitasdirect.covea.pfs.dao.pfs;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import fr.securitasdirect.covea.pfs.ProviderCredentials;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthClient;
import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthInterceptor;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableConfigurationProperties(ApplicationProperties.class)
public class CoveaClientsConfiguration {

    private final ApplicationProperties configuration;

    @Autowired
    public CoveaClientsConfiguration(final ApplicationProperties configuration) {
        this.configuration = configuration;
    }

    @Bean
    public CoveAuthInterceptor coveAuthInterceptor(final CoveAuthClient coveAuthClient) {
        return new CoveAuthInterceptor(coveAuthClient);
    }

    @Bean
    @Scope("prototype")
    public ClientHttpRequestFactory requestFactory() {
        final HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        if (StringUtils.isNotBlank(configuration.getProxyHost())) {
            final HttpHost proxy = new HttpHost(configuration.getProxyHost(), configuration.getProxyPort());
            httpClientBuilder.setProxy(proxy);
        }
        return new HttpComponentsClientHttpRequestFactory(
                httpClientBuilder.build()
        );
    }

    @Bean("pfsTemplate")
    public RestTemplate pfsTemplate(final RestTemplateBuilder builder, final CoveAuthInterceptor coveAuthInterceptor) {
        return builder
                .requestFactory(requestFactory())
                .additionalInterceptors(coveAuthInterceptor, new ContentTypeOverrideInterceptor())
                .messageConverters(jsonConverter())
                .rootUri(configuration.getPfs().getRootUri())
                .setConnectTimeout(configuration.getPfs().getConnectTimeout())
                .setReadTimeout(configuration.getPfs().getReadTimeout())
                .build();
    }

    @Bean("coveAuthTemplate")
    public RestTemplate coveAuthTemplate(final RestTemplateBuilder builder) {
        return builder
                .requestFactory(requestFactory())
                .messageConverters(jsonConverter(), new FormHttpMessageConverter())
                .rootUri(configuration.getCoveAuth().getRootUri())
                .setConnectTimeout(configuration.getCoveAuth().getConnectTimeout())
                .setReadTimeout(configuration.getCoveAuth().getReadTimeout())
                .build();
    }

    @Bean
    public ProviderCredentials providerCredentials() {
        return configuration.getCoveAuth().getProviderCredentials();
    }

    private MappingJackson2HttpMessageConverter jsonConverter() {
        final MappingJackson2HttpMessageConverter pfsConverter = new MappingJackson2HttpMessageConverter();
        final ObjectMapper objectMapper = pfsConverter.getObjectMapper();
        objectMapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
        return pfsConverter;
    }
}
