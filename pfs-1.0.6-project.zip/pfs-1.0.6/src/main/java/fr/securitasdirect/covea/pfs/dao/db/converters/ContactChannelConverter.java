package fr.securitasdirect.covea.pfs.dao.db.converters;

import fr.securitasdirect.covea.pfs.dao.db.model.ContactChannel;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class ContactChannelConverter implements AttributeConverter<ContactChannel, String> {

    private static final String FACE_À_FACE = "Face-à-face";

    private static final String APPEL_ENTRANT = "Appel entrant";

    private static final String APPEL_SORTANT = "Appel sortant";

    private static final String DEMANDE_DE_RAPPEL = "Demande de rappel";

    @Override
    public String convertToDatabaseColumn(final ContactChannel attribute) {
        if (attribute == null) {
            return null;
        }
        switch (attribute) {
            case FACE_A_FACE:
                return FACE_À_FACE;
            case APPEL_ENTRANT:
                return APPEL_ENTRANT;
            case APPEL_SORTANT:
                return APPEL_SORTANT;
            case CALLBACK:
                return DEMANDE_DE_RAPPEL;
            default:
                return null;
        }
    }

    @Override
    public ContactChannel convertToEntityAttribute(final String dbData) {
        if (dbData == null) {
            return null;
        }
        switch (dbData) {
            case FACE_À_FACE:
                return ContactChannel.FACE_A_FACE;
            case APPEL_ENTRANT:
                return ContactChannel.APPEL_ENTRANT;
            case APPEL_SORTANT:
                return ContactChannel.APPEL_SORTANT;
            case DEMANDE_DE_RAPPEL:
                return ContactChannel.CALLBACK;
            default:
                return null;
        }
    }
}
