package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "\"uid329_Contact\"")
public class ContactEvent extends BaseEvent<Contact> {

    public ContactEvent() {}

    public ContactEvent(final Cartouche cartouche, final Contact payload) {
        super(cartouche, payload);
    }
}
