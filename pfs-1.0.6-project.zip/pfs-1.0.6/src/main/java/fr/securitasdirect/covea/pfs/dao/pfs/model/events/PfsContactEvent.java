package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("CONTACT")
public class PfsContactEvent extends BasePfsEvent<PfsContact> {

    public PfsContactEvent() {}

    public PfsContactEvent(final PfsCartouche cartouche, final PfsContact payload) {
        super(cartouche, payload);
    }

    @Override
    @JsonProperty("donneesFonctionnelles")
    public PfsContact getPayload() {
        return super.payload;
    }
}
