package fr.securitasdirect.covea.pfs.dao.db.model;

public enum PriceSplitting {
    UNIQUE,
    MENSUEL,
    ANNUEL
}
