package fr.securitasdirect.covea.pfs.dao.pfs.auth;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonValue;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Objects;

@JsonRootName("token")
public class CoveAuthResponse {

    private String token;

    public CoveAuthResponse() {}

    @JsonCreator
    public CoveAuthResponse(final String token) {
        this.token = token;
    }

    @JsonValue
    public String getToken() {
        return token;
    }

    public void setToken(final String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("token", token)
                .toString();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final CoveAuthResponse that = (CoveAuthResponse) o;
        return Objects.equals(token, that.token);
    }

    @Override
    public int hashCode() {
        return Objects.hash(token);
    }
}
