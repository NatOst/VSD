package fr.securitasdirect.covea.pfs.dao.db.model;

public enum CustomerBrand {
    GMF,
    MAAF,
    MMA
}
