package fr.securitasdirect.covea.pfs.web;

import fr.securitasdirect.covea.pfs.service.OutboundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EventsResource {

    @Autowired
    private OutboundService outboundService;

    @RequestMapping(path = "/events", method = RequestMethod.PUT, produces = MediaType.TEXT_PLAIN_VALUE)
    public String publishEvents() {
        outboundService.publishEvents();
        return "OK";
    }
}
