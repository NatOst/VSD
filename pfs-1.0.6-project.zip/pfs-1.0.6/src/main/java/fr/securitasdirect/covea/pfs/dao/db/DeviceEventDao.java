package fr.securitasdirect.covea.pfs.dao.db;

import fr.securitasdirect.covea.pfs.dao.db.model.DeviceEvent;

public interface DeviceEventDao extends EventDao<DeviceEvent> {
}
