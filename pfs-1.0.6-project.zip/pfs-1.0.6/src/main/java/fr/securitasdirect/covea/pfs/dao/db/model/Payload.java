package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Embeddable;

@Embeddable
public interface Payload {
}
