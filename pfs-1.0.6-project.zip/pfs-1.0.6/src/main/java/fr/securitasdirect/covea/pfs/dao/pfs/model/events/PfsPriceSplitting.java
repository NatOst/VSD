package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

public enum PfsPriceSplitting {
    UNIQUE,
    MENSUEL,
    ANNUEL
}
