package fr.securitasdirect.covea.pfs.service;

import fr.securitasdirect.covea.pfs.dao.pfs.ApplicationProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.TaskUtils;

import javax.annotation.PostConstruct;

@Configuration
@EnableConfigurationProperties(ApplicationProperties.class)
public class ServicesConfiguration {

    private final ApplicationProperties configuration;

    private final OutboundService outboundService;

    @Autowired
    public ServicesConfiguration(final ApplicationProperties configuration, final OutboundService outboundService) {
        this.configuration = configuration;
        this.outboundService = outboundService;
    }

    @Bean
    public TaskScheduler scheduler() {
        final ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setErrorHandler(TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER);
        return scheduler;
    }

    @PostConstruct
    public void scheduleEventsEmission() {
        scheduler().schedule(outboundService::publishEvents, configuration.getSchedule());
    }
}
