package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

@Deprecated
public enum PfsCoveaLead {
    PFS,
    AIS
}
