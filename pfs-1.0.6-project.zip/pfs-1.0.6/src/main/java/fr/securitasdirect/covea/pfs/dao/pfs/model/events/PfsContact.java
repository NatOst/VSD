package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.Optional;

public class PfsContact implements PfsPayload {

    @JsonProperty("dateContact")
    private ZonedDateTime date;

    @JsonProperty("cdCanalContact")
    private PfsContactChannel channel;

    @JsonProperty("issueContact")
    private String output;

    public ZonedDateTime getDate() {
        return date;
    }

    public void setDate(final ZonedDateTime date) {
        this.date = date;
    }

    public PfsContactChannel getChannel() {
        return channel;
    }

    public void setChannel(final PfsContactChannel channel) {
        this.channel = channel;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(final String output) {
        this.output = output;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final PfsContact that = (PfsContact) o;
        return Optional.ofNullable(date).map(e -> e.isEqual(that.date)).orElse(that.date == null) &&
                channel == that.channel &&
                Objects.equals(output, that.output);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, channel, output);
    }
}
