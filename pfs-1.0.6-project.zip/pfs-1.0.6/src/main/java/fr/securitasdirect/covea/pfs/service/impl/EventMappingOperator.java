package fr.securitasdirect.covea.pfs.service.impl;

import java.util.function.Function;

@FunctionalInterface
interface EventMappingOperator<E, P> extends Function<E, P> {
}
