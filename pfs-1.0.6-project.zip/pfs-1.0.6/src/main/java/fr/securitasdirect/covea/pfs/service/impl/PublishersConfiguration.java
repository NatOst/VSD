package fr.securitasdirect.covea.pfs.service.impl;

import fr.securitasdirect.covea.pfs.dao.db.ContactEventDao;
import fr.securitasdirect.covea.pfs.dao.db.CustomerLifeEventDao;
import fr.securitasdirect.covea.pfs.dao.db.DeviceEventDao;
import fr.securitasdirect.covea.pfs.dao.db.model.ContactEvent;
import fr.securitasdirect.covea.pfs.dao.db.model.CustomerLifeEvent;
import fr.securitasdirect.covea.pfs.dao.db.model.DeviceEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.PfsClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class PublishersConfiguration {

    private final EventMapper eventMapper;

    private final PfsClient pfsClient;

    private final PlatformTransactionManager txManager;

    private final CounterService counterService;

    @Autowired
    public PublishersConfiguration(final EventMapper eventMapper, final PfsClient pfsClient,
                                   final PlatformTransactionManager txManager, final CounterService counterService) {
        this.eventMapper = eventMapper;
        this.pfsClient = pfsClient;
        this.txManager = txManager;
        this.counterService = counterService;
    }

    @Bean
    public EventPublisher contactEventEmitter(final ContactEventDao contactEventDao) {
        return new EventPublisherImpl<>(ContactEvent.class, contactEventDao, eventMapper::contactEventToPfs, pfsClient, txManager, counterService);
    }

    @Bean
    public EventPublisher customerLifeEventEmitter(final CustomerLifeEventDao customerLifeEventDao) {
        return new EventPublisherImpl<>(CustomerLifeEvent.class, customerLifeEventDao, eventMapper::customerLifeEventToPfs, pfsClient, txManager, counterService);
    }

    @Bean
    public EventPublisher deviceEventEmitter(final DeviceEventDao deviceEventDao) {
        return new EventPublisherImpl<>(DeviceEvent.class, deviceEventDao, eventMapper::deviceEventToPfs, pfsClient, txManager, counterService);
    }
}
