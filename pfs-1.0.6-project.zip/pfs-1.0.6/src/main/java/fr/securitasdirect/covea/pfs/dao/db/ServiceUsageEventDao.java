package fr.securitasdirect.covea.pfs.dao.db;

import fr.securitasdirect.covea.pfs.dao.db.model.ServiceUsageEvent;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface ServiceUsageEventDao extends EventDao<ServiceUsageEvent> {
}
