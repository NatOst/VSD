package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "\"uid329_Equipement\"")
public class DeviceEvent extends BaseEvent<Device> {

    public DeviceEvent() {
    }

    public DeviceEvent(final Cartouche cartouche, final Device payload) {
        super(cartouche, payload);
    }
}
