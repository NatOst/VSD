package fr.securitasdirect.covea.pfs.dao.db.model;

import java.time.Instant;

public interface Event<T extends Payload> {
    Long getId();

    Cartouche getCartouche();

    T getPayload();

    Instant getInsertionTime();

    Instant getPublicationTime();

    void setPublicationTime(Instant publicationTime);
}
