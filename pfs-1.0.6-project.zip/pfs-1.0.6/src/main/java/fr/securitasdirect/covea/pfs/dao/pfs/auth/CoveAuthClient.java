package fr.securitasdirect.covea.pfs.dao.pfs.auth;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import fr.securitasdirect.covea.pfs.ProviderCredentials;
import fr.securitasdirect.covea.pfs.dao.pfs.ApplicationProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

import static java.lang.String.format;

@Component
public class CoveAuthClient {

    private final RestTemplate coveAuthTemplate;

    private final ApplicationProperties applicationProperties;

    @Autowired
    public CoveAuthClient(@Qualifier("coveAuthTemplate") final RestTemplate coveAuthTemplate,
                          final ApplicationProperties applicationProperties) {
        this.coveAuthTemplate = coveAuthTemplate;
        this.applicationProperties = applicationProperties;
    }

    public DecodedJWT authenticate() {
        try {
            final MultiValueMap<String, String> body = buildForm();
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            final HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(body, headers);
            final CoveAuthResponse response = coveAuthTemplate.postForObject("/authorize", entity, CoveAuthResponse.class);
            final String token = response.getToken();
            final JWT decodedToken = JWT.decode(token);
            if (applicationProperties.getCoveAuth().getIssuer().equals(decodedToken.getIssuer())) {
                return decodedToken;
            } else {
                throw new CoveAuthLoginException(format("Bad issuer. Expected %1$s, found %2$s.", applicationProperties.getCoveAuth().getIssuer(), decodedToken.getIssuer()));
            }
        } catch (final HttpClientErrorException e) {
            if (HttpStatus.UNAUTHORIZED.equals(e.getStatusCode())) {
                throw new CoveAuthLoginException(e);
            } else {
                throw e;
            }
        }
    }

    private MultiValueMap<String, String> buildForm() {
        final ProviderCredentials providerCredentials = applicationProperties.getCoveAuth().getProviderCredentials();
        final MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.set("grant_type", providerCredentials.getGrantType());
        form.set("username", providerCredentials.getUsername());
        form.set("password", providerCredentials.getPassword());
        form.set("origin", providerCredentials.getOrigin());
        form.set("population", providerCredentials.getPopulation());
        form.set("response_type", providerCredentials.getResponseType());
        form.set("token_exp", providerCredentials.getTokenExp());
        return form;
    }
}
