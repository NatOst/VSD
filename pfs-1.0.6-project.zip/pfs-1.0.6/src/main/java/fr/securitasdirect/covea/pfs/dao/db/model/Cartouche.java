package fr.securitasdirect.covea.pfs.dao.db.model;

import fr.securitasdirect.covea.pfs.dao.db.converters.DateConverter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

@Embeddable
public class Cartouche {

    @Column(name = "\"cdLeadCovea\"")
    private String coveaLeadCode;

    @Column(name = "\"IdLeadCovea\"")
    private String coveaLeadId;

    @Column(name = "\"ID_Client\"")
    private String customerId;

    @Column(name = "\"Marque\"")
    @Enumerated(EnumType.STRING)
    private CustomerBrand brand;

    @Column(name = "\"IDfournisseur\"")
    private String providerId;

    @Column(name = "\"IdOffre\"")
    private String offerId;

    @Column(name = "\"Date_Emission\"")
    @Convert(converter = DateConverter.class)
    private LocalDate emissionTime;

    @Column(name = "\"IdEquipementfournisseur\"")
    private String providerDeviceId;

    @Column(name = "\"IDclientfournisseur\"")
    private String providerCustomerId;

    public Cartouche() {}

    public Cartouche(final String customerId, final CustomerBrand brand, final String providerId, final String offerId,
                     final LocalDate emissionTime, final String coveaLeadCode, final String coveaLeadId,
                     final String providerDeviceId, final String providerCustomerId) {
        this.customerId = customerId;
        this.brand = brand;
        this.providerId = providerId;
        this.offerId = offerId;
        this.emissionTime = emissionTime;
        this.coveaLeadCode = coveaLeadCode;
        this.coveaLeadId = coveaLeadId;
        this.providerDeviceId = providerDeviceId;
        this.providerCustomerId = providerCustomerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(final String customerId) {
        this.customerId = customerId;
    }

    public CustomerBrand getBrand() {
        return brand;
    }

    public void setBrand(final CustomerBrand brand) {
        this.brand = brand;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(final String providerId) {
        this.providerId = providerId;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(final String offerId) {
        this.offerId = offerId;
    }

    public LocalDate getEmissionTime() {
        return emissionTime;
    }

    public void setEmissionTime(final LocalDate emissionTime) {
        this.emissionTime = emissionTime;
    }

    public String getCoveaLeadCode() {
        return coveaLeadCode;
    }

    public void setCoveaLeadCode(final String coveaLeadCode) {
        this.coveaLeadCode = coveaLeadCode;
    }

    public String getCoveaLeadId() {
        return coveaLeadId;
    }

    public void setCoveaLeadId(final String coveaLeadId) {
        this.coveaLeadId = coveaLeadId;
    }

    public String getProviderDeviceId() {
        return providerDeviceId;
    }

    public void setProviderDeviceId(final String providerDeviceId) {
        this.providerDeviceId = providerDeviceId;
    }

    public String getProviderCustomerId() {
        return providerCustomerId;
    }

    public void setProviderCustomerId(final String providerCustomerId) {
        this.providerCustomerId = providerCustomerId;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (!(o instanceof Cartouche)) return false;
        final Cartouche cartouche = (Cartouche) o;
        return Objects.equals(customerId, cartouche.customerId) &&
                Objects.equals(brand, cartouche.brand) &&
                Objects.equals(providerId, cartouche.providerId) &&
                Objects.equals(offerId, cartouche.offerId) &&
                Optional.ofNullable(emissionTime).map(e -> e.isEqual(cartouche.emissionTime)).orElse(cartouche.emissionTime == null) &&
                Objects.equals(coveaLeadCode, cartouche.coveaLeadCode) &&
                Objects.equals(coveaLeadId, cartouche.coveaLeadId) &&
                Objects.equals(providerDeviceId, cartouche.providerDeviceId) &&
                Objects.equals(providerCustomerId, cartouche.providerCustomerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, brand, providerId, offerId, emissionTime, coveaLeadCode, coveaLeadId,
                providerDeviceId, providerCustomerId);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("coveaLeadCode", coveaLeadCode)
                .append("coveaLeadId", coveaLeadId)
                .append("customerId", customerId)
                .append("brand", brand)
                .append("providerId", providerId)
                .append("offerId", offerId)
                .append("emissionTime", emissionTime)
                .append("providerEquipmentId", providerDeviceId)
                .append("providerCustomerId", providerCustomerId)
                .toString();
    }
}
