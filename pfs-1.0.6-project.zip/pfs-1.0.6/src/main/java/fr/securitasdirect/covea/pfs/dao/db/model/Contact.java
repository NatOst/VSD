package fr.securitasdirect.covea.pfs.dao.db.model;

import fr.securitasdirect.covea.pfs.dao.db.converters.ContactChannelConverter;
import fr.securitasdirect.covea.pfs.dao.db.converters.DateConverter;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

public class Contact implements Payload {

    @Column(name = "\"Date_contact\"")
    @Convert(converter = DateConverter.class)
    private LocalDate date;

    @Column(name = "\"canal_contact\"")
    @Convert(converter = ContactChannelConverter.class)
    private ContactChannel channel;

    @Column(name = "\"Issue_contact\"")
    private String output;

    public LocalDate getDate() {
        return date;
    }

    public void setDate(final LocalDate date) {
        this.date = date;
    }

    public ContactChannel getChannel() {
        return channel;
    }

    public void setChannel(final ContactChannel channel) {
        this.channel = channel;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(final String output) {
        this.output = output;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final Contact that = (Contact) o;
        return Optional.ofNullable(date).map(e -> e.isEqual(that.date)).orElse(that.date == null) &&
                channel == that.channel &&
                Objects.equals(output, that.output);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, channel, output);
    }
}
