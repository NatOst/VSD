package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Column;
import java.util.Objects;

public class CustomerLife implements Payload {

    @Column(name = "\"civilité\"")
    private Boolean prefixChanged;

    @Column(name = "\"prenom\"")
    private Boolean firstNameChanged;

    @Column(name = "\"nom\"")
    private Boolean lastNameChanged;

    @Column(name = "\"rue\"")
    private Boolean streetChanged;

    @Column(name = "\"codePostal\"")
    private Boolean postcodeChanged;

    @Column(name = "\"commune\"")
    private Boolean cityChanged;

    @Column(name = "\"pays\"")
    private Boolean countryChanged;

    @Column(name = "\"tel_dom\"")
    private Boolean homePhoneNumberChanged;

    @Column(name = "\"tel_GSM\"")
    private Boolean mobilePhoneNumberChanged;

    @Column(name = "\"email\"")
    private Boolean emailChanged;

    public Boolean getPrefixChanged() {
        return prefixChanged;
    }

    public void setPrefixChanged(final Boolean prefixChanged) {
        this.prefixChanged = prefixChanged;
    }

    public Boolean getFirstNameChanged() {
        return firstNameChanged;
    }

    public void setFirstNameChanged(final Boolean firstNameChanged) {
        this.firstNameChanged = firstNameChanged;
    }

    public Boolean getLastNameChanged() {
        return lastNameChanged;
    }

    public void setLastNameChanged(final Boolean lastNameChanged) {
        this.lastNameChanged = lastNameChanged;
    }

    public Boolean getStreetChanged() {
        return streetChanged;
    }

    public void setStreetChanged(final Boolean streetChanged) {
        this.streetChanged = streetChanged;
    }

    public Boolean getPostcodeChanged() {
        return postcodeChanged;
    }

    public void setPostcodeChanged(final Boolean postcodeChanged) {
        this.postcodeChanged = postcodeChanged;
    }

    public Boolean getCityChanged() {
        return cityChanged;
    }

    public void setCityChanged(final Boolean cityChanged) {
        this.cityChanged = cityChanged;
    }

    public Boolean getCountryChanged() {
        return countryChanged;
    }

    public void setCountryChanged(final Boolean countryChanged) {
        this.countryChanged = countryChanged;
    }

    public Boolean getHomePhoneNumberChanged() {
        return homePhoneNumberChanged;
    }

    public void setHomePhoneNumberChanged(final Boolean homePhoneNumberChanged) {
        this.homePhoneNumberChanged = homePhoneNumberChanged;
    }

    public Boolean getMobilePhoneNumberChanged() {
        return mobilePhoneNumberChanged;
    }

    public void setMobilePhoneNumberChanged(final Boolean mobilePhoneNumberChanged) {
        this.mobilePhoneNumberChanged = mobilePhoneNumberChanged;
    }

    public Boolean getEmailChanged() {
        return emailChanged;
    }

    public void setEmailChanged(final Boolean emailChanged) {
        this.emailChanged = emailChanged;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final CustomerLife that = (CustomerLife) o;
        return Objects.equals(prefixChanged, that.prefixChanged) &&
                Objects.equals(firstNameChanged, that.firstNameChanged) &&
                Objects.equals(lastNameChanged, that.lastNameChanged) &&
                Objects.equals(streetChanged, that.streetChanged) &&
                Objects.equals(postcodeChanged, that.postcodeChanged) &&
                Objects.equals(cityChanged, that.cityChanged) &&
                Objects.equals(countryChanged, that.countryChanged) &&
                Objects.equals(homePhoneNumberChanged, that.homePhoneNumberChanged) &&
                Objects.equals(mobilePhoneNumberChanged, that.mobilePhoneNumberChanged) &&
                Objects.equals(emailChanged, that.emailChanged);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prefixChanged, firstNameChanged, lastNameChanged, streetChanged, postcodeChanged, cityChanged, countryChanged, homePhoneNumberChanged, mobilePhoneNumberChanged, emailChanged);
    }
}
