package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Objects;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "cdTypeEvt"
)
@JsonRootName("publierServiceNonAssurantiel")
abstract class BasePfsEvent<T extends PfsPayload> implements PfsEvent<T> {

    @JsonUnwrapped
    private PfsCartouche cartouche;

    protected T payload;

    BasePfsEvent() {}

    BasePfsEvent(final PfsCartouche cartouche, final T payload) {
        this.cartouche = cartouche;
        this.payload = payload;
    }

    @Override
    public final PfsCartouche getCartouche() {
        return cartouche;
    }

    public final void setCartouche(final PfsCartouche cartouche) {
        this.cartouche = cartouche;
    }

    public final void setPayload(final T payload) {
        this.payload = payload;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (!(o instanceof BasePfsEvent)) return false;
        final BasePfsEvent<?> that = (BasePfsEvent<?>) o;
        return Objects.equals(cartouche, that.cartouche) &&
                Objects.equals(payload, that.payload);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cartouche, payload);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("cartouche", cartouche)
                .append("payload", payload)
                .toString();
    }
}
