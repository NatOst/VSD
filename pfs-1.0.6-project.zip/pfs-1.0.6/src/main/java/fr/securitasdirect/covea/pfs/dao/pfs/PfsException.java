package fr.securitasdirect.covea.pfs.dao.pfs;

public class PfsException extends Exception {
    public PfsException() {
    }

    public PfsException(final String message) {
        super(message);
    }

    public PfsException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public PfsException(final Throwable cause) {
        super(cause);
    }

    public PfsException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
