package fr.securitasdirect.covea.pfs.service.impl;

import fr.securitasdirect.covea.pfs.service.OutboundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class OutboundServiceImpl implements OutboundService {

    private final List<EventPublisher> eventPublishers;

    @Autowired
    public OutboundServiceImpl(final Collection<? extends EventPublisher> eventEmitters) {
        this.eventPublishers = new ArrayList<>(eventEmitters);
    }

    @Override
    public void publishEvents() {
        eventPublishers.forEach(EventPublisher::publishEvents);
    }
}
