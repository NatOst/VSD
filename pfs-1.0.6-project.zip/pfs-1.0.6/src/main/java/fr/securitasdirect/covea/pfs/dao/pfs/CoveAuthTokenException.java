package fr.securitasdirect.covea.pfs.dao.pfs;

import fr.securitasdirect.covea.pfs.dao.pfs.PfsException;

public class CoveAuthTokenException extends PfsException {
    public CoveAuthTokenException() {
    }

    public CoveAuthTokenException(final String message) {
        super(message);
    }

    public CoveAuthTokenException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public CoveAuthTokenException(final Throwable cause) {
        super(cause);
    }

    public CoveAuthTokenException(final String message, final Throwable cause, final boolean enableSuppression, final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
