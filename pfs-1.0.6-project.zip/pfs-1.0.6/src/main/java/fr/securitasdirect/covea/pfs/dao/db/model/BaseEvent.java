package fr.securitasdirect.covea.pfs.dao.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.persistence.*;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

@MappedSuperclass
abstract class BaseEvent<T extends Payload> implements Event<T> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"ID\"")
    protected Long id;

    @Embedded
    protected Cartouche cartouche;

    @Embedded
    protected T payload;

    @Column(name = "\"date_insert_SD\"")
    protected Instant insertionTime;

    @Column(name = "\"date_Traitement_OAB\"")
    protected Instant publicationTime;

    BaseEvent() {
        this.cartouche = new Cartouche();
    }

    BaseEvent(final Cartouche cartouche, final T payload) {
        this.cartouche = cartouche;
        this.payload = payload;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    @Override
    public Cartouche getCartouche() {
        return cartouche;
    }

    public void setCartouche(final Cartouche cartouche) {
        this.cartouche = cartouche;
    }

    @Override
    public T getPayload() {
        return payload;
    }

    public void setPayload(final T payload) {
        this.payload = payload;
    }

    @Override
    public Instant getInsertionTime() {
        return insertionTime;
    }

    public void setInsertionTime(final Instant insertionTime) {
        this.insertionTime = insertionTime;
    }

    @Override
    public Instant getPublicationTime() {
        return publicationTime;
    }

    @Override
    public void setPublicationTime(final Instant publicationTime) {
        this.publicationTime = publicationTime;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (!(o instanceof BaseEvent)) return false;
        final BaseEvent<?> that = (BaseEvent<?>) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(cartouche, that.cartouche) &&
                Objects.equals(payload, that.payload) &&
                Objects.equals(insertionTime, that.insertionTime) &&
                Objects.equals(publicationTime, that.publicationTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cartouche, payload);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", id)
                .append("cartouche", cartouche)
                .append("payload", payload)
                .append("insertionTime", insertionTime)
                .append("publicationTime", publicationTime)
                .toString();
    }
}
