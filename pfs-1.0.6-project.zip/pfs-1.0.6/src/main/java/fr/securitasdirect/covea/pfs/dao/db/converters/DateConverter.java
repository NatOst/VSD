package fr.securitasdirect.covea.pfs.dao.db.converters;


import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Converter
public class DateConverter implements AttributeConverter<LocalDate, String> {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @Override
    public String convertToDatabaseColumn(final LocalDate attribute) {
        return Optional
                .ofNullable(attribute)
                .map(a -> a.format(FORMATTER))
                .orElse(null);
    }

    @Override
    public LocalDate convertToEntityAttribute(final String dbData) {
        return Optional
                .ofNullable(dbData)
                .map(d -> LocalDate.parse(d, FORMATTER))
                .orElse(null);
    }
}
