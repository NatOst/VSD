package fr.securitasdirect.covea.pfs.dao.db.model;

import javax.persistence.Entity;
import javax.persistence.Table;

//@Entity
//@Table(name = "Usage")
public class ServiceUsageEvent extends BaseEvent<ServiceUsage> {
    public ServiceUsageEvent() {
    }

    public ServiceUsageEvent(final Cartouche cartouche, final ServiceUsage payload) {
        super(cartouche, payload);
    }
}
