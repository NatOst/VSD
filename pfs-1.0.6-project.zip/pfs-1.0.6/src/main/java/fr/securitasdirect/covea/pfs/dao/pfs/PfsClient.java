package fr.securitasdirect.covea.pfs.dao.pfs;

import fr.securitasdirect.covea.pfs.dao.pfs.auth.CoveAuthLoginException;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsEvent;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.PfsPayload;
import fr.securitasdirect.covea.pfs.dao.pfs.model.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class PfsClient {
    private final RestTemplate client;

    @Autowired
    public PfsClient(final @Qualifier("pfsTemplate") RestTemplate client) {
        this.client = client;
    }

    public <T extends PfsPayload> void publishEvent(final PfsEvent<T> pfsEvent) throws PfsException {
        try {
            final ResponseEntity<Response> resp = client.postForEntity("/PUB_SENAT_1", pfsEvent, Response.class);
            if (!HttpStatus.OK.equals(resp.getStatusCode())) {
                throw new PfsException(resp.getBody().toString());
            }
        } catch (final HttpStatusCodeException e) {
            if (HttpStatus.UNAUTHORIZED.equals(e.getStatusCode())) {
                throw new CoveAuthTokenException(e);
            } else {
                throw new PfsException(e);
            }
        } catch (final CoveAuthLoginException e) {
            throw e;
        } catch (final RuntimeException e) {
            throw new PfsException(e);
        }
    }
}
