package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("USAGE_SERVICE")
public class PfsServiceUsageEvent extends BasePfsEvent<PfsServiceUsage> {
    public PfsServiceUsageEvent() {
    }

    public PfsServiceUsageEvent(final PfsCartouche cartouche, final PfsServiceUsage payload) {
        super(cartouche, payload);
    }

    @Override
    @JsonProperty("donneesFonctionnelles")
    public PfsServiceUsage getPayload() {
        return super.payload;
    }
}
