package fr.securitasdirect.covea.pfs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class Application extends SpringBootServletInitializer {

    public static final String MDC_EVENT_KIND = "eventKind";

    public static final String COUNTER_EVENTS_PUBLISHED = "counter.events.published.";

    public static final String COUNTER_EVENTS_FAILED = "counter.events.failed.";

    @Override
    protected SpringApplicationBuilder configure(final SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }

    public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
