package fr.securitasdirect.covea.pfs.dao.db;

import fr.securitasdirect.covea.pfs.dao.db.model.ContactEvent;

public interface ContactEventDao extends EventDao<ContactEvent> {
}
