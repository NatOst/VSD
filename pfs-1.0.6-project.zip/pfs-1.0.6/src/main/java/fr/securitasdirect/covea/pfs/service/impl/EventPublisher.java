package fr.securitasdirect.covea.pfs.service.impl;

public interface EventPublisher {
    void publishEvents();
}
