package fr.securitasdirect.covea.pfs.service.impl;

import fr.securitasdirect.covea.pfs.dao.db.model.*;
import fr.securitasdirect.covea.pfs.dao.pfs.model.events.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@Mapper(componentModel = "spring")
public interface EventMapper {

    PfsContactEvent contactEventToPfs(ContactEvent event);
    PfsContact contactToPfs(Contact contact);
    PfsContactChannel contactChannelToPfs(ContactChannel contactChannel);

    PfsCustomerLifeEvent customerLifeEventToPfs(CustomerLifeEvent event);
    PfsCustomerLife customerLifeToPfs(CustomerLife customerLife);
    PfsAddress addressToPfs(Address address);

    PfsDeviceEvent deviceEventToPfs(DeviceEvent event);
    @Mapping(target = "priceSplitting", constant = "MENSUEL")
    @Mapping(target = "start", ignore = true)
    @Mapping(target = "end", ignore = true)
    @Mapping(target = "serviceURL", ignore = true)
    PfsDevice deviceToPfs(Device device);
    PfsPriceSplitting priceSplittingToPds(PriceSplitting priceSplitting);

    PfsServiceUsageEvent serviceUsageEventToPFs(ServiceUsageEvent event);
    PfsServiceUsage serviceUsageToPfs(ServiceUsage serviceUsage);

    PfsCartouche cartoucheToPfs(Cartouche cartouche);

    PfsCustomerBrand customerBrandToPfs(CustomerBrand customerBrand);

    default ZonedDateTime localDateToZoned(final LocalDate local) {
        if (local == null) {
            return null;
        }
        return ZonedDateTime.of(local, LocalTime.NOON, ZoneId.systemDefault());
    }
}
