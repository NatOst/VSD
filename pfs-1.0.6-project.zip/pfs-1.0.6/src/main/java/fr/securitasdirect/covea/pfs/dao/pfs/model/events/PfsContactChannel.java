package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

public enum PfsContactChannel {
    FACE_A_FACE,
    MAIL,
    APPEL_ENTRANT,
    APPEL_SORTANT,
    CALLBACK
}
