package fr.securitasdirect.covea.pfs.dao.pfs;

public class ConnectionProperties {
    private String rootUri;

    private int connectTimeout;

    private int readTimeout;

    public final String getRootUri() {
        return rootUri;
    }

    public final void setRootUri(final String rootUri) {
        this.rootUri = rootUri;
    }

    public final int getConnectTimeout() {
        return connectTimeout;
    }

    public final void setConnectTimeout(final int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public final int getReadTimeout() {
        return readTimeout;
    }

    public final void setReadTimeout(final int readTimeout) {
        this.readTimeout = readTimeout;
    }
}
