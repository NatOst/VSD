package fr.securitasdirect.covea.pfs.dao.db.model;

import fr.securitasdirect.covea.pfs.dao.db.converters.DateConverter;

import javax.persistence.Column;
import javax.persistence.Convert;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

public class Device implements Payload {

    @Column(name = "\"Id_Offre\"")
    private String deviceId;

    @Column(name = "\"Date_Souscription\"")
    @Convert(converter = DateConverter.class)
    private LocalDate usage;

    @Column(name = "\"Libellé\"")
    private String serviceName;

    @Column(name = "\"EtatEquipement\"")
    private String status;

    @Column(name = "\"Cotisation\"")
    private BigDecimal price;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    public LocalDate getUsage() {
        return usage;
    }

    public void setUsage(final LocalDate usage) {
        this.usage = usage;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(final String serviceName) {
        this.serviceName = serviceName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(final BigDecimal price) {
        this.price = price;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final Device device = (Device) o;
        return Objects.equals(deviceId, device.deviceId) &&
                Optional.ofNullable(usage).map(u -> u.isEqual(device.usage)).orElse(device.usage == null) &&
                Objects.equals(serviceName, device.serviceName) &&
                Objects.equals(status, device.status) &&
                Objects.equals(price, device.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(deviceId, usage, serviceName, status, price);
    }
}
