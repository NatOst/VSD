package fr.securitasdirect.covea.pfs.dao.pfs.auth;

public interface CoveAuth {
    String TOKEN_HEADER = "covea-access-token";
}
