package fr.securitasdirect.covea.pfs.dao.pfs.model.events;

public interface PfsPayload {
}
