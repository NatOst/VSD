package fr.securitasdirect.covea.pfs;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ProviderCredentials {

    private String grantType;

    private String username;

    private String password;

    private String origin;

    private String population;

    private String responseType;

    private String tokenExp;

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(final String grantType) {
        this.grantType = grantType;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(final String origin) {
        this.origin = origin;
    }

    public String getPopulation() {
        return population;
    }

    public void setPopulation(final String population) {
        this.population = population;
    }

    public String getResponseType() {
        return responseType;
    }

    public void setResponseType(final String responseType) {
        this.responseType = responseType;
    }

    public String getTokenExp() {
        return tokenExp;
    }

    public void setTokenExp(final String tokenExp) {
        this.tokenExp = tokenExp;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(final String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("grantType", grantType)
                .append("username", username)
                .append("password", "***")
                .append("origin", origin)
                .append("population", population)
                .append("responseType", responseType)
                .append("tokenExp", tokenExp)
                .toString();
    }
}
