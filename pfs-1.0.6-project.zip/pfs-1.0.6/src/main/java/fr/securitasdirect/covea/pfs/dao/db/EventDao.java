package fr.securitasdirect.covea.pfs.dao.db;

import fr.securitasdirect.covea.pfs.dao.db.model.Event;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface EventDao<T extends Event> extends CrudRepository<T, Long> {
    Iterable<T> findAllByPublicationTimeNullOrderByInsertionTimeAsc();

    long countAllByPublicationTimeNull();
}
