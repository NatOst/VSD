package fr.securitasdirect.covea.pfs;

import fr.securitasdirect.covea.pfs.dao.pfs.ConnectionProperties;

public class CoveAuthProperties extends ConnectionProperties {

    private final ProviderCredentials providerCredentials;

    private String issuer;

    public CoveAuthProperties() {
        providerCredentials = new ProviderCredentials();
    }

    public ProviderCredentials getProviderCredentials() {
        return providerCredentials;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(final String issuer) {
        this.issuer = issuer;
    }
}
