USE [Covea]
GO

/****** Object:  Table [dbo].[uid329_Contact]    Script Date: 24/03/2017 15:26:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[uid329_Contact](
  [date_insert_SD] [datetime] NOT NULL,
  [ID] [int] IDENTITY(1,1) NOT NULL,
  [ID_Client] [varchar](15) NULL,
  [Marque] [varchar](20) NULL,
  [IDfournisseur] [varchar](8) NULL,
  [IDclientfournisseur] [varchar](10) NULL,
  [Date_Emission] [varchar](10) NULL,
  [cdTypeEvt] [varchar](7) NOT NULL,
  [cdLeadCovea] [varchar](20) NULL,
  [IdLeadCovea] [varchar](50) NULL,
  [IdOffre] [varchar](12) NULL,
  [IdEquipementfournisseur] [varchar](12) NULL,
  [Date_contact] [varchar](10) NULL,
  [canal_contact] [varchar](100) NULL,
  [Issue_contact] [varchar](250) NULL,
  [date_Traitement_OAB] [datetime] NULL
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[uid329_Client](
  [ID] [int] IDENTITY(1,1) NOT NULL,
  [date_insert_SD] [datetime] NOT NULL,
  [ID_Client] [varchar](15) NULL,
  [Marque] [varchar](20) NULL,
  [IDfournisseur] [varchar](8) NULL,
  [IDclientfournisseur] [varchar](10) NULL,
  [Date_Emission] [varchar](10) NULL,
  [cdTypeEvt] [varchar](7) NOT NULL,
  [cdLeadCovea] [varchar](20) NULL,
  [IdLeadCovea] [varchar](50) NULL,
  [IdOffre] [varchar](12) NULL,
  [IdEquipementfournisseur] [varchar](12) NULL,
  [civilité] [BIT] NOT NULL,
  [nom] [BIT] NOT NULL,
  [prenom] [BIT] NOT NULL,
  [rue] [BIT] NOT NULL,
  [codePostal] [BIT] NOT NULL,
  [commune] [BIT] NOT NULL,
  [pays] [BIT] NOT NULL,
  [tel_dom] [BIT] NOT NULL,
  [tel_GSM] [BIT] NOT NULL,
  [email] [BIT] NOT NULL,
  [date_Traitement_OAB] [datetime] NULL
) ON [PRIMARY]


GO

CREATE TABLE [dbo].[uid329_Equipement](
  [date_insert_SD] [datetime] NOT NULL,
  [ID] [int] IDENTITY(1,1) NOT NULL,
  [ID_Client] [varchar](15) NULL,
  [Marque] [varchar](20) NULL,
  [IDfournisseur] [varchar](8) NOT NULL,
  [IDclientfournisseur] [varchar](10) NULL,
  [Date_Emission] [varchar](10) NULL,
  [cdTypeEvt] [varchar](7) NOT NULL,
  [cdLeadCovea] [varchar](20) NULL,
  [IdLeadCovea] [varchar](50) NULL,
  [IdOffre] [varchar](10) NULL,
  [IdEquipementfournisseur] [varchar](12) NULL,
  [Id_Offre] [varchar](12) NULL,
  [Libellé] [varchar](255) NULL,
  [Date_Souscription] [varchar](10) NULL,
  [Cotisation] [money] NULL,
  [EtatEquipement] [varchar](7) NULL,
  [date_Traitement_OAB] [datetime] NULL
) ON [PRIMARY]


GO


SET ANSI_PADDING OFF
GO
