/*
CREATE TABLE xxx (
  -- Base
  "id" NUMERIC(18) NOT NULL PRIMARY KEY,
  "dateInsertion" TIMESTAMP NOT NULL,
  -- Cartouche
  "cdLeadCovea" VARCHAR(10) NOT NULL,
  "idLeadCovea" NVARCHAR(200) NOT NULL,
  "idClient" NVARCHAR(200) NOT NULL,
  "marque" VARCHAR(4) NOT NULL,
  "idFournisseur" NVARCHAR(200) NOT NULL,
  "idOffre" NVARCHAR(200) NOT NULL,
  "dateEmission" TIMESTAMP NOT NULL,
  "idEquipementFournisseur" NVARCHAR(200),
  "idClientFournisseur" NVARCHAR(200)
);
*/

CREATE SEQUENCE Events;

CREATE TABLE "uid329_Contact" (
  -- Base
  "date_insert_SD" TIMESTAMP NOT NULL,
  "ID" NUMERIC(18) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  "date_Traitement_OAB" TIMESTAMP NULL,
  -- Cartouche
  "ID_Client" VARCHAR(15) NULL,
  "Marque" VARCHAR(20) NULL,
  "IDfournisseur" VARCHAR(8) NULL,
  "IDclientfournisseur" VARCHAR(10) NULL,
  "Date_Emission" VARCHAR(10) NULL,
  "cdLeadCovea" VARCHAR(20) NULL,
  "IdLeadCovea" VARCHAR(50) NULL,
  "IdOffre" VARCHAR(12) NULL,
  "IdEquipementfournisseur" VARCHAR(12) NULL,
  -- Contact
  "Date_contact" VARCHAR(10),
  "canal_contact" VARCHAR(100),
  "Issue_contact" VARCHAR(250)
);

CREATE TABLE "uid329_Client" (
  -- Base
  "date_insert_SD" TIMESTAMP NOT NULL,
  "ID" NUMERIC(18) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  "date_Traitement_OAB" TIMESTAMP NULL,
  -- Cartouche
  "ID_Client" VARCHAR(15) NULL,
  "Marque" VARCHAR(20) NULL,
  "IDfournisseur" VARCHAR(8) NULL,
  "IDclientfournisseur" VARCHAR(10) NULL,
  "Date_Emission" VARCHAR(10) NULL,
  "cdLeadCovea" VARCHAR(20) NULL,
  "IdLeadCovea" VARCHAR(50) NULL,
  "IdOffre" VARCHAR(12) NULL,
  "IdEquipementfournisseur" VARCHAR(12) NULL,
  -- Vie du client
  "civilité" BOOLEAN NOT NULL,
  "prenom" BOOLEAN NOT NULL,
  "nom" BOOLEAN NOT NULL,
  "rue" BOOLEAN NOT NULL,
  "codePostal" BOOLEAN NOT NULL,
  "commune" BOOLEAN NOT NULL,
  "pays" BOOLEAN NOT NULL,
  "tel_dom" BOOLEAN NOT NULL,
  "tel_GSM" BOOLEAN NOT NULL,
  "email" BOOLEAN NOT NULL
);

CREATE TABLE "uid329_Equipement" (
  -- Base
  "date_insert_SD" TIMESTAMP NOT NULL,
  "ID" NUMERIC(18) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  "date_Traitement_OAB" TIMESTAMP NULL,
  -- Cartouche
  "ID_Client" VARCHAR(15) NULL,
  "Marque" VARCHAR(20) NULL,
  "IDfournisseur" VARCHAR(8) NULL,
  "IDclientfournisseur" VARCHAR(10) NULL,
  "Date_Emission" VARCHAR(10) NULL,
  "cdLeadCovea" VARCHAR(20) NULL,
  "IdLeadCovea" VARCHAR(50) NULL,
  "IdOffre" VARCHAR(12) NULL,
  "IdEquipementfournisseur" VARCHAR(12) NULL,
  -- Équipement
  "Id_Offre" VARCHAR(12) NULL,
  "Libellé" VARCHAR(255) NULL,
  "Date_Souscription" VARCHAR(10) NULL,
  "Cotisation" DECIMAL(9,2),
  "EtatEquipement" VARCHAR(7)
);